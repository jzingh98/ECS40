//Jagveer Singh
//ECS 40 HW 0: Makefile

#include <iostream>

int main() {
	std::cout << "Hello ECS40 from 03737" << std::endl;
	return 0;
}
